مشروع Android لتطبيق حساب خدمتي

هذا مشروع Android Studio يحتوي على واجهة حساب خدمتي داخل WebView ويعمل بملف HTML مرفق دون الحاجة إلى استضافة خارجية.

مهم جداً:
- هذه ملفات المشروع المصدرية وليست APK جاهزاً.
- يلزم Android Studio مع Android SDK لبناء APK.
- افتح مجلد HesabKhedmti في Android Studio، انتظر Gradle Sync، ثم Build > Build Bundle(s) / APK(s) > Build APK(s).
- بعد نجاح البناء ستجد APK غالباً داخل app/build/outputs/apk/debug/app-debug.apk.
- البيانات مخزنة محلياً في WebView؛ صدّر نسخة احتياطية من التطبيق بانتظام إذا كانت خاصية التصدير متاحة في الواجهة.


تحديث 1.1:
- تمت إضافة WebChromeClient لدعم نوافذ JavaScript: alert و confirm و prompt.
- تم رفع versionCode إلى 2 و versionName إلى 1.1.
- تم الحفاظ على applicationId والـ namespace ومفتاح localStorage الموجود في index.html لتفادي بدء بيانات جديدة.
- جرّب التحديث على نسخة احتياطية/جهاز تجريبي أولاً. لا يمكن ضمان بقاء البيانات في كل الحالات؛ لا تحذف التطبيق القديم قبل الاختبار.


إعداد البناء التلقائي على GitHub:
- تم إضافة .github/workflows/build-apk.yml لبناء APK تلقائياً.
- ارفع محتويات مجلد HesabKhedmti إلى جذر المستودع GitHub (وليس ملف ZIP وحده).
- بعد رفع الملفات، افتح تبويب Actions وشغّل Build HesabKhedmti APK إذا لم يبدأ تلقائياً.
- بعد نجاح التشغيل، افتح نتيجة التشغيل (workflow run) ونزّل Artifact باسم HesabKhedmti-debug-apk.
- هذا Debug APK للتجربة فقط. لم يتم بناء APK أو اختباره في هذه البيئة.
