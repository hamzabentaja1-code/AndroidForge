package ma.hesabkhedmti.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int CREATE_BACKUP_REQUEST = 4101;
    private static final int RESTORE_BACKUP_REQUEST = 4102;
    private WebView webView;
    private String pendingBackupJson;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new BackupBridge(), "AndroidBackup");
        webView.addJavascriptInterface(new PrintBridge(), "AndroidPrint");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class BackupBridge {
        @JavascriptInterface
        public void saveBackup(String json) {
            runOnUiThread(() -> {
                pendingBackupJson = json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "hesab-khedmti-backup.json");
                startActivityForResult(intent, CREATE_BACKUP_REQUEST);
            });
        }

        @JavascriptInterface
        public void restoreBackup() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "text/plain"});
                startActivityForResult(intent, RESTORE_BACKUP_REQUEST);
            });
        }
    }


    private class PrintBridge {
        @JavascriptInterface
        public void printDevis(String html) {
            runOnUiThread(() -> {
                try {
                    PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
                    if (printManager == null) throw new IllegalStateException("Print service unavailable");
                    WebView printView = new WebView(MainActivity.this);
                    WebSettings printSettings = printView.getSettings();
                    printSettings.setJavaScriptEnabled(false);
                    printSettings.setAllowFileAccess(true);
                    printView.setWebViewClient(new WebViewClient() {
                        @Override public void onPageFinished(WebView view, String url) {
                            PrintAttributes attrs = new PrintAttributes.Builder()
                                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                    .setResolution(new PrintAttributes.Resolution("devis", "Devis", 300, 300))
                                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                    .build();
                            printManager.print("HesabKhedmti-Devis", view.createPrintDocumentAdapter("HesabKhedmti-Devis"), attrs);
                        }
                    });
                    printView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "تعذر فتح الطباعة. جرّب من جديد.", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent resultData) {
        super.onActivityResult(requestCode, resultCode, resultData);
        if (resultCode != RESULT_OK || resultData == null || resultData.getData() == null) {
            pendingBackupJson = null;
            return;
        }

        Uri uri = resultData.getData();
        if (requestCode == CREATE_BACKUP_REQUEST) {
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null || pendingBackupJson == null) throw new Exception("تعذر فتح الملف");
                out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                out.flush();
                Toast.makeText(this, "تم حفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "ما قدرناش نحفظو النسخة. عاود المحاولة.", Toast.LENGTH_LONG).show();
            } finally {
                pendingBackupJson = null;
            }
        } else if (requestCode == RESTORE_BACKUP_REQUEST) {
            try (InputStream in = getContentResolver().openInputStream(uri);
                 BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line).append('\n');
                String json = sb.toString();
                String quoted = org.json.JSONObject.quote(json);
                webView.evaluateJavascript("window.onBackupLoaded && window.onBackupLoaded(" + quoted + ")", null);
            } catch (Exception e) {
                Toast.makeText(this, "ما قدرناش نقراو الملف. اختار نسخة JSON صحيحة.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
