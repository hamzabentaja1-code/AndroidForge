مشروع Android لتطبيق حساب خدمتي

هذا مشروع Android Studio يحتوي على واجهة حساب خدمتي داخل WebView ويعمل بملف HTML مرفق دون الحاجة إلى استضافة خارجية.

مهم جداً:
- هذه ملفات المشروع المصدرية وليست APK جاهزاً.
- يلزم Android Studio مع Android SDK لبناء APK.
- افتح مجلد HesabKhedmti في Android Studio، انتظر Gradle Sync، ثم Build > Build Bundle(s) / APK(s) > Build APK(s).
- بعد نجاح البناء ستجد APK غالباً داخل app/build/outputs/apk/debug/app-debug.apk.
- البيانات مخزنة محلياً في WebView؛ صدّر نسخة احتياطية من التطبيق بانتظام إذا كانت خاصية التصدير متاحة في الواجهة.
